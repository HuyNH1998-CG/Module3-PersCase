create definer = root@localhost trigger product_BEFORE_UPDATE
    before update
    on product
    for each row
BEGIN
if new.trongkho > 0 then set new.tinhtrang = "Còn hàng"; else set new.tinhtrang = "Hết hàng";
end if;
END;

