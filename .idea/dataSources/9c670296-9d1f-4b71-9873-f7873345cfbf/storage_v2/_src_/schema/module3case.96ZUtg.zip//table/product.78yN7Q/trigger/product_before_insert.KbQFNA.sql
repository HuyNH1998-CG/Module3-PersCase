create definer = root@localhost trigger product_BEFORE_INSERT
    before insert
    on product
    for each row
BEGIN
if new.trongkho > 0 then set new.tinhtrang = "Còn hàng"; else set new.tinhtrang = "hết hàng";
end if;
END;

